<?php echo e($slot); ?>

<?php /**PATH C:\dev\confam\confam-api\vendor\laravel\framework\src\Illuminate\Mail\resources\views\text/footer.blade.php ENDPATH**/ ?>